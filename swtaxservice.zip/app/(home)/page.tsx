// app/page.tsx
export { default } from './site/page';
