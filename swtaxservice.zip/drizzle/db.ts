
export * from "./schema";  // ← re-exports all tables
export { db } from "./client";  // ← re-exports the database client
